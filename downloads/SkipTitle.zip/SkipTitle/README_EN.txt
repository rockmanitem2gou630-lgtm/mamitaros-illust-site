SkipTitle.js
Plugin for RPG Maker MZ

Author: Mamitaros

---

## Overview

A simple plugin that skips the title screen and starts
a new game immediately after launching the game.

Useful for projects that do not need a title screen,
or games designed to open directly into the main game screen.

---

## How to Use

1. Place SkipTitle.js in your project's js/plugins folder.
2. Enable it in the Plugin Manager in RPG Maker MZ.

That's all!

---

## Terms of Use

* Free for commercial and non-commercial use.
* Modification is allowed.
* Credit is optional.
* No usage report is required.

If you would like to give credit, please use:

Mamitaros

Feel free to use and modify this plugin for your projects.

---

## Compatibility Note

This plugin overrides:

Scene_Boot.prototype.startNormalGame

It may conflict with other plugins that modify the same function.
