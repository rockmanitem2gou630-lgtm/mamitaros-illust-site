# Epic Seven Fan-made 3D Asset

This is an unofficial 3D asset created for **Epic Seven** fan art.

Please use this asset only as a reference for personal illustration and fan art creation.

## You may

* Use it for personal fan art and illustration.
* Use it as a reference for poses or composition.
* Modify it for your own artwork.

## You may NOT

* Redistribute or resell this asset.
* Use it for commercial purposes.
* Use it for AI training or AI-generated content.
* 3D print or sell physical copies.
* Use it in MMD, VRChat, games, mods, or any other 3D applications.
* Use it for offensive or inappropriate content.
* Use it in ways that may harm the image of Epic Seven or its creators.

## Credit

Credit is appreciated but not required.

If you would like to credit the creator, please use:

Mamitaros

## Disclaimer

This is an unofficial fan-made asset.

Epic Seven and all related characters, names, and properties are owned by Smilegate Holdings, Inc. and their respective owners.
