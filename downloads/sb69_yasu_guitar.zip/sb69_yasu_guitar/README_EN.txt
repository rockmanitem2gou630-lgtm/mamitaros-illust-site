SHOW BY ROCK!! Fan-made 3D Asset
Yasu's Guitar: Yata no Tetsu Konjou Karasu Shiki

This is an unofficial fan-made 3D asset based on
Yasu's guitar, "Yata no Tetsu Konjou Karasu Shiki,"
from SHOW BY ROCK!!

Please use this asset only as a reference or aid for
personal fan art and illustration.


Included Files

- sb69_yasu_guitar.fbx
- sb69_yasu_guitar_texture.png


You May

- Use it for personal fan art and illustration.
- Use it as a reference for shape, angle, and composition.
- Modify it as needed for your own illustration work.


You May NOT

- Redistribute, repost, or resell this asset.
- Claim this asset as your own work.
- Use it for commercial purposes.
- Use it for AI training or AI-generated content.
- Use it for 3D printing.
- Use it in MMD, VRChat, games, mods, videos,
  or any other project that directly uses the 3D model.
- Use it as an asset for other franchises or characters.
- Use it for offensive or inappropriate content.
- Use it in ways that may significantly harm the image of
  SHOW BY ROCK!! or its creators.

This asset may only be used as an aid for illustration production.


Credit

Credit is appreciated but not required.

If you would like to credit the creator, please use:

Mamitaros


Disclaimer

The creator is not responsible for any problems or damages
resulting from the use of this asset.

This is an unofficial fan-made work.
SHOW BY ROCK!! and all related characters, names, and properties
belong to their respective rights holders.